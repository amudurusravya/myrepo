%clc;    clear;

%tic;
global U0;
global U1;

%N = 1;
N = 1000;
Seed = 1;
count_zero = 0;
z = seed_gen(1);

display(z);
R1 = tausworthe_gen(z, N);


z = seed_gen(2);
R2 = tausworthe_gen(z, N);
U1 = bitand(R2,65535);

r4 = bitand(R2,4294901760); % to retrieve MSB 16 bits
r5 = uint64(bitshift(r4,-16)); % right shift bits and or with U0 
r1_64 = uint64(R1);
r6 = r1_64*(2^16); % to convert R1 to 64 bits
U0 = bitor(r6,r5);

for k = 1 : N
    Fr_bin = dec2bin(U0(k),48);
    display(Fr_bin);
    %% below logic is to find leading zeros
    % c will have number of zeros preceeding 1.
    display(k);
    Fr_bin(49) = num2str(1);
    c=1;
    while(str2num(Fr_bin(c))==0) 
        c=c+1;
    end
    %% below logic to find index of logarithm coefficients
    Fr_dec = 0;
    coe_val = 0;
    c = c+1;
    %display(Fr_bin);
    %display(c);
    bit_pos = 7;
    for i = c : c+7    % Note that the 1st char is the decimal dot !
        %display(Fr_bin);
        coe_val = coe_val + ((2^bit_pos) * str2num( Fr_bin(i) )) ;
        bit_pos=bit_pos-1;
    end
    coe_val = coe_val +1;
    %display(coe_val);
    %% below logic is to compute value of x
    Fr_dec = 1;
    bit_pos = -1;
    for i = c : 48    % Note that the 1st char is the decimal dot !
        %display(Fr_bin);
        Fr_dec = Fr_dec + ((2^bit_pos) * str2num( Fr_bin(i) )) ;
        bit_pos=bit_pos-1;
    end
    %% below logic is to compute value of log using coefficients
    %display(Fr_dec);
    c0 = fi(c0_log(coe_val),1,30,28);
    c1 = fi(c1_log(coe_val),1,22,20);
    c2 = fi(c2_log(coe_val),1,13,11);
    log_val = c0+(c1*Fr_dec)+(c2*Fr_dec*Fr_dec); %-log(Fr_dec)
    final_val(k)= (((c-1)*log(2))+log_val)*2; % range reconstruction step
    %display(final_val(k));
    %% to compute sqrt
    %% range reduction steps
    log_bin = f_d2b(final_val(k));
    %display(final_val(k));
    %display(log_bin);
    c=1;
    while(str2num(log_bin(c))==0) 
        %count_zeros = count_zeros+1;
        c=c+1;
    end
    c = c-1; % indicates number of leading zeros
    exp_f = 5-c;
    
    x_f_c = bitshift(bin2dec(log_bin),-exp_f);
    if(exp_f == 1 || exp_f == 3 || exp_f == 5)
        x_f = bitshift(x_f_c,-1);
    else 
        x_f = x_f_c;
    end
    %% calculate sqrt(x_f)
    x_f_bin = dec2bin(x_f,31);
    c = 1;
    coe_sqrt_val = 0;
    coe_sqrt_bin = x_f_bin(8:13);
    for i = 1 : 6    % Note that the 1st char is the decimal dot !
        coe_sqrt_val = coe_sqrt_val + ((2^(6-i)) * str2num( coe_sqrt_bin(i) )) ;
    end
    coe_sqrt_val = coe_sqrt_val +1;
    if(exp_f == 1 || exp_f == 3 || exp_f == 5)
        c0 = c0_sqrt1(coe_sqrt_val);
        c1 = c1_sqrt1(coe_sqrt_val);
    else
        c0 = c0_sqrt2(coe_sqrt_val);
        c1 = c1_sqrt2(coe_sqrt_val);
    end
    % find value of x_f
    x_f_dec = 0;
    for i = 1: 31
        x_f_dec = x_f_dec + ((2^(7-i)) * str2num(x_f_bin(i)));
    end
    sqrt_val(k) = vpa(c1*x_f_dec) + c0;
    %display(sqrt_val(k));
    %% range recosntruction
    if(exp_f == 1 || exp_f == 3 || exp_f == 5)
        exp_f_c = (exp_f +1)/2; % right shift operation
    else
        exp_f_c = exp_f / 2;
    end
    final_sqrt_val(k) = sqrt_val(k) * (2^exp_f_c);
   %display(final_sqrt_val(k));
end
 %% cosine approximation

 for k = 1:N
     cos_inp_bin = dec2bin(U1(k),16);
     %display(cos_inp_bin);
     x_g_a = cos_inp_bin(3:16);
     x_b = 16383 - bin2dec(x_g_a);
     x_g_b = dec2bin(x_b,14);
     %display(x_g_a);
     %display(x_g_b);
     x_g_a_dec = 0;
     for i = 1: 14
         x_g_a_dec = x_g_a_dec + ((2^(-i)) * str2num(x_g_a(i)));
     end
     x_g_b_dec = 0;
     for i = 1: 14
         x_g_b_dec = x_g_b_dec + ((2^(-i)) * str2num(x_g_b(i)));
     end
     coe_cosine_bin = x_g_a(1:7);
     coe_sine_bin = x_g_b(1:7);
     coe_cosine_val = bin2dec(coe_cosine_bin);
     coe_sine_val = bin2dec(coe_sine_bin);
     c0_cosine = c_0(coe_cosine_val+1);
     c1_cosine = c_1(coe_cosine_val+1);
     c0_sine = c_0(coe_sine_val+1);
     c1_sine = c_1(coe_sine_val+1);
 %{
     display(c0_cosine);
     display(c1_cosine);
     display(c0_sine);
     display(c1_sine);
   %}
     y_g_b = c1_sine*x_g_b_dec + c0_sine;
     y_g_a = c1_cosine*x_g_a_dec + c0_cosine;
     %display(y_g_a);
     %display(y_g_b);
     %y_c = cos(x_g_a_dec*(pi/2));
     %y_s = cos(x_g_b_dec*(pi/2));
     
     switch(cos_inp_bin(1:2))
         case '00' 
             g0(k) = y_g_b;
             g1(k) = y_g_a;
         case '01' 
             g0(k) = y_g_a;
             g1(k) = -y_g_b;
         case '10' 
             g0(k) = -y_g_b;
             g1(k) = -y_g_a;
         case '11' 
             g0(k) = -y_g_a;
             g1(k) = y_g_b;
     end       
     %display(g0(k));
     %display(g1(k));
     x0(k) = g0(k) * final_sqrt_val(k);
     x1(k) = g1(k) * final_sqrt_val(k);
 end
 %{
 for k = 1 : N
     x0(k) = g0(k) * final_sqrt_val(k);
     x1(k) = g1(k) * final_sqrt_val(k);
 %    display(x0(k));
     
 %    display(x1(k));
     %display(final_sqrt_val(k));
     
     %display(f_d2bs(double(x0(k))));
     %display(f_d2bs(double(x1(k))));
 end
 %}
 %display(x0_n);
 %display(x1_n);
 
hist([double(x0),double(x1)], N);
%{
for k = 1 : N
    
    Fr_dec(k) = 0;
    Fr_bin = dec2bin(U1(k),16);
    for i = 1 : 16    % Note that the 1st char is the decimal dot !
        %display(Fr_bin);
        Fr_dec(k) = Fr_dec(k) + 2^(-i) * str2num( Fr_bin(i) ) ;   
    end 
end
g0 = sin(2*pi*Fr_dec);
g1 = cos(2*pi*Fr_dec);
for n = 1:N
    x0(n) = final_sqrt_val(n)*g0(n);
    x1(n) = final_sqrt_val(n)*g1(n);
end
hist([double(x0),double(x1)], N);
%}
%% to cross check value of log
%{
for k = 1 : N
    Fr_dec(k) = 0;
    Fr_bin = dec2bin(U0(k),48);
    for i = 1 : 48    % Note that the 1st char is the decimal dot !
        %display(Fr_bin);
        Fr_dec(k) = Fr_dec(k) + 2^(-i) * str2num( Fr_bin(i) ) ;   
    end
end

%display(Fr_dec);
e = -2*log(Fr_dec);
for i = 1:N
display(e(i)-log_final_val(i));
end
%}

%% to cross check value of sqrt
for k = 1:N
    e(k) = sqrt(final_val(k));
    error(k) = e(k) - final_sqrt_val(k);
end
%display(double(error));
%k = f_d2b(e(5));
%display(k);
%display(f_b2d(k));

fileIO = fopen('inputs_new.txt','w');
 i=1;
 
 for i = 1:N
     sign_bit_x0 = '0';
     sign_bit_x1 = '0';
     if(x0(i)<0)
         x0(i) = x0(i)*(-1);
         sign_bit_x0 = '1';
     end
     if(x1(i)<0)
         x1(i) = x1(i)*(-1);
         sign_bit_x1 = '1';
     end
     
     x0_bin = f_d2b(double(x0(i)));
     x1_bin = f_d2b(double(x1(i)));
     
     fprintf(fileIO,'%s %s \r\n',strcat(sign_bit_x0,x0_bin(3:18)),strcat(sign_bit_x1,x1_bin(3:18)));
 end
 fclose(fileIO);