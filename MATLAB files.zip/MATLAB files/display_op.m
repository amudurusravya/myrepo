% this file is to plot output from modelsim
 fileIO = fopen('outputs.txt','r');
 i=1;
 while (~feof(fileIO))
     f = fgetl(fileIO);
     x0 = f(1:17);
     x1 = f(19:35);
     x0_dec(i) = 0;
     for n= 2:17
        x0_dec(i) = x0_dec(i) + 2^(6-n) * str2num( x0(n) ) ; % 2^(5-(n-1))
     end
     x1_dec(i) = 0;
     for n= 2:17
        x1_dec(i) = x1_dec(i) + 2^(6-n) * str2num( x1(n) ) ; % 2^(5-(n-1))
     end
     if(x0(1) == '1')
         x0_dec(i) = x0_dec(i)*(-1);
     end
     if(x1(1) == '1')
         x1_dec(i) = x1_dec(i)*(-1);
     end

     i = i+1;
     %bin2dec(f)
     %display(x1);
 end
 if(i == 1)
     display('file is empty');
     return;
 end
     %bin2dec(f)
 %    display(x1);
 hist([x0_dec,x1_dec], i-1);
 display(i);